using System.Text.Json;
using Sfk.ProductAssistant.Models;

namespace Sfk.ProductAssistant.Services;

public sealed class ProductRepository
{
    private readonly Lazy<Dictionary<string, Product>> _products;
    private static readonly JsonSerializerOptions _jsonOpts = new() { PropertyNameCaseInsensitive = true };

    public ProductRepository()
    {
        _products = new Lazy<Dictionary<string, Product>>(() => LoadProducts(), true);
    }

    private static Dictionary<string, Product> LoadProducts()
    {
        // Reads both local JSON files and merges
        var dataDir = Path.Combine(AppContext.BaseDirectory, "Data");
        var files = new[] { "bearings_a.json", "bearings_b.json", "6025 N.json", "6025.json" }
            .Select(f => Path.Combine(dataDir, f))
            .Where(File.Exists)
            .ToArray();

        var dict = new Dictionary<string, Product>(StringComparer.OrdinalIgnoreCase);
        foreach (var file in files)
        {
            var json = File.ReadAllText(file);
            var list = JsonSerializer.Deserialize<List<Product>>(json, _jsonOpts) ?? new();
            foreach (var p in list)
            {
                if (string.IsNullOrWhiteSpace(p.Designation)) continue;
                if (!dict.TryGetValue(p.Designation, out var existing))
                {
                    dict[p.Designation] = p;
                }
                else
                {
                    // merge attributes (existing takes precedence)
                    foreach (var kv in p.Attributes)
                    {
                        if (!existing.Attributes.ContainsKey(kv.Key))
                            existing.Attributes[kv.Key] = kv.Value;
                    }
                }
            }
        }
        return dict;
    }

    public Product? GetByDesignation(string designation)
    {
        if (string.IsNullOrWhiteSpace(designation)) return null;
        _products.Value.TryGetValue(designation, out var product);
        return product;
    }

    public (bool found, string? value) TryGetAttribute(string designation, string attribute)
    {
        var p = GetByDesignation(designation);
        if (p is null) return (false, null);
        if (p.Attributes.TryGetValue(attribute, out var v)) return (true, v);
        // Simple aliasing for common terms
        var aliases = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "width", "width" }, { "diameter", "diameter" }, { "height", "height" },
            { "bore", "bore" }, { "inner_diameter", "bore" }, { "outer_diameter", "diameter" }
        };
        if (aliases.TryGetValue(attribute, out var canon) && p.Attributes.TryGetValue(canon, out var v2))
            return (true, v2);
        return (false, null);
    }

    public IEnumerable<string> GetAttributes(string designation)
        => GetByDesignation(designation)?.Attributes.Keys ?? Enumerable.Empty<string>();
}
