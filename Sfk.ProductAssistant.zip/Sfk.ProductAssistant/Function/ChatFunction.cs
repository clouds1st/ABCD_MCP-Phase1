using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Text.Json;
using System.Text.RegularExpressions;
using Sfk.ProductAssistant.Agents;
using Sfk.ProductAssistant.Models;

namespace Sfk.ProductAssistant.Function;

public sealed class ChatFunction
{
    private readonly ILogger _logger;
    private readonly OrchestratorAgent _orchestrator;
    private readonly QaAgent _qa;
    private readonly FeedbackAgent _feedback;

    public ChatFunction(ILoggerFactory loggerFactory, OrchestratorAgent orchestrator, QaAgent qa, FeedbackAgent feedback)
    {
        _logger = loggerFactory.CreateLogger<ChatFunction>();
        _orchestrator = orchestrator;
        _qa = qa;
        _feedback = feedback;
    }

    [Function("chat")]
    public async Task<HttpResponseData> Run([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req, CancellationToken ct)
    {
        try
        {
            var body = await new StreamReader(req.Body).ReadToEndAsync(ct);
            if (string.IsNullOrWhiteSpace(body))
                return await BadRequest(req, "Empty request body.");

            ChatRequest? input;
            try
            {
                input = JsonSerializer.Deserialize<ChatRequest>(body, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            }
            catch
            {
                return await BadRequest(req, "Invalid JSON.");
            }

            if (input is null || string.IsNullOrWhiteSpace(input.Message))
                return await BadRequest(req, "Field 'message' is required.");

            // Basic input hardening
            if (input.Message.Length > 1000)
                return await BadRequest(req, "Message too long.");

            var conversationId = string.IsNullOrWhiteSpace(input.ConversationId)
                ? CreateConversationId()
                : SanitizeId(input.ConversationId!);

            var intent = await _orchestrator.ClassifyAsync(input.Message, ct);

            if (intent == "feedback")
            {
                var reply = await _feedback.CaptureAsync(conversationId, input.Message, ct);
                return await Ok(req, new ChatResponse
                {
                    ConversationId = conversationId,
                    Agent = "feedback",
                    Reply = reply
                });
            }
            else
            {
                var (reply, designation, attribute) = await _qa.AnswerAsync(conversationId, input.Message, ct);
                return await Ok(req, new ChatResponse
                {
                    ConversationId = conversationId,
                    Agent = "qa",
                    Reply = reply,
                    Designation = designation,
                    Attribute = attribute
                });
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled error");
            var res = req.CreateResponse(HttpStatusCode.InternalServerError);
            await res.WriteStringAsync("Internal error.");
            return res;
        }
    }

    private static string CreateConversationId() => Guid.NewGuid().ToString("N");

    private static string SanitizeId(string id)
    {
        // allow only safe chars
        id = id.Trim();
        id = Regex.Replace(id, @"[^a-zA-Z0-9_\-]", "_");
        return string.IsNullOrWhiteSpace(id) ? CreateConversationId() : id;
    }

    private static async Task<HttpResponseData> Ok(HttpRequestData req, object payload)
    {
        var res = req.CreateResponse(HttpStatusCode.OK);
        res.Headers.Add("Content-Type", "application/json; charset=utf-8");
        await res.WriteStringAsync(JsonSerializer.Serialize(payload));
        return res;
    }

    private static async Task<HttpResponseData> BadRequest(HttpRequestData req, string message)
    {
        var res = req.CreateResponse(HttpStatusCode.BadRequest);
        await res.WriteStringAsync(JsonSerializer.Serialize(new { error = message }));
        return res;
    }
}
