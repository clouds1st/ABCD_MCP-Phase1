using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using Sfk.ProductAssistant.Services;
using Sfk.ProductAssistant.Services.KeyValueStores;
using Sfk.ProductAssistant.Plugins;
using Sfk.ProductAssistant.Agents;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureAppConfiguration((ctx, builder) =>
    {
        builder.AddEnvironmentVariables();
        if (ctx.HostingEnvironment.IsDevelopment())
        {
            builder.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true);
        }
    })
    .ConfigureServices((ctx, services) =>
    {
        var cfg = ctx.Configuration;

        // Configuration values
        string aoaiEndpoint = cfg["AZURE_OPENAI_ENDPOINT"] ?? throw new InvalidOperationException("AZURE_OPENAI_ENDPOINT is required");
        string aoaiKey = cfg["AZURE_OPENAI_KEY"] ?? throw new InvalidOperationException("AZURE_OPENAI_KEY is required");
        string deployment = cfg["AZURE_OPENAI_DEPLOYMENT"] ?? throw new InvalidOperationException("AZURE_OPENAI_DEPLOYMENT is required");
        string modelName = cfg["AZURE_OPENAI_MODEL"] ?? throw new InvalidOperationException("AZURE_OPENAI_MODEL is required");
    bool useRedis = (cfg["USE_REDIS"] ?? "false").Equals("true", StringComparison.OrdinalIgnoreCase);
        string? redisConn = cfg["REDIS_CONNECTION_STRING"];

        // Key-value store (cache + feedback)
        if (useRedis)
        {
            if (string.IsNullOrWhiteSpace(redisConn))
                throw new InvalidOperationException("USE_REDIS=true but REDIS_CONNECTION_STRING is not set.");
            services.AddSingleton<IKeyValueStore>(new RedisKeyValueStore(redisConn));
        }
        else
        {
            services.AddSingleton<IKeyValueStore, MemoryKeyValueStore>();
        }

        // State + repository
        services.AddSingleton<ConversationStateStore>();
        services.AddSingleton<ProductRepository>();

        // Build a kernel factory for reuse by agents with Azure OpenAI
        // Fixed: use the IServiceProvider overload so we return a Func<Kernel> (factory) correctly.
        services.AddSingleton<Func<Kernel>>(sp =>
        {
            // Return a factory that creates a new Kernel when invoked.
            return () =>
            {
                var builder = Kernel.CreateBuilder();
                builder.AddAzureOpenAIChatCompletion(
                    modelId: modelName,
                    deploymentName: deployment,
                    endpoint: aoaiEndpoint,
                    apiKey: aoaiKey);
                return builder.Build();
            };
        });

        // Plugins (registered for DI so agents can attach them to their kernels)
        services.AddSingleton<ExtractionPlugin>();
        services.AddSingleton<DatasheetPlugin>();
        services.AddSingleton<CachePlugin>();
        services.AddSingleton<FeedbackPlugin>();

        // Agents
        services.AddSingleton<OrchestratorAgent>();
        services.AddSingleton<QaAgent>();
        services.AddSingleton<FeedbackAgent>();
    })
    .Build();

await host.RunAsync();
