using Microsoft.SemanticKernel;
using Sfk.ProductAssistant.Services;
using System.ComponentModel;

namespace Sfk.ProductAssistant.Plugins;

public sealed class DatasheetPlugin
{
    private readonly ProductRepository _repo;

    public DatasheetPlugin(ProductRepository repo) => _repo = repo;

    [KernelFunction, Description("Lookup a specific attribute value from local datasheets for a product designation.")]
    public string? LookupAttribute(
        [Description("Product designation (e.g., 6205)")] string designation,
        [Description("Attribute name (e.g., width, diameter, height, bore)")] string attribute)
    {
        var (found, value) = _repo.TryGetAttribute(designation, attribute);
        return found ? value : null;
    }

    [KernelFunction, Description("List available attribute names for a designation.")]
    public IEnumerable<string> ListAttributes(
        [Description("Product designation (e.g., 6205)")] string designation)
        => _repo.GetAttributes(designation);
}
