using System.Collections.Concurrent;

namespace Sfk.ProductAssistant.Services.KeyValueStores;

public sealed class MemoryKeyValueStore : IKeyValueStore
{
    private readonly ConcurrentDictionary<string, (string value, DateTimeOffset? expires)> _kv = new();
    private readonly ConcurrentDictionary<string, List<string>> _lists = new();

    public Task<string?> GetAsync(string key, CancellationToken ct = default)
    {
        if (_kv.TryGetValue(key, out var entry))
        {
            if (entry.expires is { } e && e < DateTimeOffset.UtcNow)
            {
                _kv.TryRemove(key, out _);
                return Task.FromResult<string?>(null);
            }
            return Task.FromResult<string?>(entry.value);
        }
        return Task.FromResult<string?>(null);
    }

    public Task SetAsync(string key, string value, TimeSpan? ttl = null, CancellationToken ct = default)
    {
        DateTimeOffset? expires = ttl.HasValue ? DateTimeOffset.UtcNow.Add(ttl.Value) : null;
        _kv[key] = (value, expires);
        return Task.CompletedTask;
    }

    public Task AppendListAsync(string key, string value, CancellationToken ct = default)
    {
        var list = _lists.GetOrAdd(key, _ => new List<string>());
        lock (list) list.Add(value);
        return Task.CompletedTask;
    }

    public Task<IReadOnlyList<string>> GetListAsync(string key, CancellationToken ct = default)
    {
        if (_lists.TryGetValue(key, out var list))
        {
            lock (list) return Task.FromResult<IReadOnlyList<string>>(list.ToList());
        }
        return Task.FromResult<IReadOnlyList<string>>(Array.Empty<string>());
    }
}
