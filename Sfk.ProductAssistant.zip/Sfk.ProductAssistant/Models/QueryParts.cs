namespace Sfk.ProductAssistant.Models;

public sealed class QueryParts
{
    public string? Designation { get; set; }
    public string? Attribute { get; set; }
    public string? Unit { get; set; }
    public string? Intent { get; set; } // optional, if extraction captures it
}
