# SKF Product Assistant (Mini) — Azure Functions + Semantic Kernel (C#)

**Architect & POC Owner: Ranjeet Bhargava**

A high-performance, single-HTTP-endpoint microservice designed to handle technical queries regarding bearing attributes. This implementation leverages **Semantic Kernel** and **Azure OpenAI** function calling to orchestrate specialized agents that interface with authoritative **local JSON datasheets**.

## Core Features

* **Unified Orchestration**: A single entry point (`/api/chat`) managing multi-agent workflows.
* **Dual-Agent Architecture**:
* **Q&A Agent**: Handles attribute lookup and technical specifications.
* **Feedback Agent**: Manages the persistence of user corrections and data refinements.


* **Intelligent Function Calling**: Seamless integration of Extraction, Cache, Datasheet, and Feedback plugins.
* **Stateful Conversations**: Contextual awareness across multiple turns managed via `conversationId`.
* **Hybrid Storage**: Local authoritative JSON datasheets with optional **Redis** integration for high-speed caching and feedback storage.
* **Hallucination Guardrails**: Strict system prompts and temperature settings () ensure responses are derived exclusively from verified JSON sources.

## Technical Requirements

* **.NET 8 SDK**
* **Azure OpenAI Resource**: Model deployment (e.g., `gpt-4o-mini`).
* **Redis** (Optional): Set `USE_REDIS=true` for distributed caching.

---

## Quick Start & Setup

1. **Configuration**: Copy `local.settings.json.example` to `local.settings.json` and populate your credentials.
2. **Data Preparation**: Ensure `Data/bearings_a.json` and `Data/bearings_b.json` are present in the root directory.
3. **Execution**:
```bash
dotnet restore
func start

```


*Alternatively:*
```bash
dotnet build
dotnet run

```



---

## Interaction Examples

### 1. Technical Attribute Query

```bash
curl -s -X POST http://localhost:7071/api/chat \
     -H "Content-Type: application/json" \
     -d '{"conversationId":"demo1","message":"What is the width of 6205?"}'

```

### 2. Stateful Follow-up

The system remembers the bearing designation from the previous turn.

```bash
curl -s -X POST http://localhost:7071/api/chat \
     -H "Content-Type: application/json" \
     -d '{"conversationId":"demo1","message":"And what about its diameter?"}'

```

### 3. Feedback & Data Correction

```bash
curl -s -X POST http://localhost:7071/api/chat \
     -H "Content-Type: application/json" \
     -d '{"conversationId":"demo1","message":"That last width is wrong—store my correction: 6205 width 15 mm."}'

```

---

## System Design & Architecture

### Environment Variables

| Variable | Description |
| --- | --- |
| `AZURE_OPENAI_ENDPOINT` | Your Azure OpenAI service URL. |
| `AZURE_OPENAI_KEY` | API Key for Azure OpenAI. |
| `AZURE_OPENAI_DEPLOYMENT` | Deployment name (e.g., `gpt-4o-mini`). |
| `USE_REDIS` | Boolean flag to toggle Redis caching. |
| `REDIS_CONNECTION_STRING` | Required if `USE_REDIS` is true. |

### Architectural Principles Applied

* **SOLID/Clean Code**: Clear separation between Function triggers, Orchestrators, Agents, and Plugins.
* **Security Baselines**: Sanitized `conversationId` inputs, fixed data directories to prevent path traversal, and environment-based secret management.
* **Cloud Native Patterns**: Dependency Injection (DI) for testability and feature flags for infrastructure components (Redis).
* **Resilience**: Comprehensive try/catch blocks within the endpoint and fallback logic for caching services.

---

**© 2026 Ranjeet Bhargava.** All rights reserved. This Proof of Concept (POC) and its architectural design are the intellectual property of Ranjeet Bhargava.

