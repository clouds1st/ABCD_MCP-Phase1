using StackExchange.Redis;

namespace Sfk.ProductAssistant.Services.KeyValueStores;

public sealed class RedisKeyValueStore : IKeyValueStore, IAsyncDisposable
{
    private readonly ConnectionMultiplexer _mux;
    private readonly IDatabase _db;

    public RedisKeyValueStore(string connectionString)
    {
        _mux = ConnectionMultiplexer.Connect(connectionString);
        _db = _mux.GetDatabase();
    }

    public Task<string?> GetAsync(string key, CancellationToken ct = default)
        => _db.StringGetAsync(key).ContinueWith(t => (string?)t.Result, ct);

    public Task SetAsync(string key, string value, TimeSpan? ttl = null, CancellationToken ct = default)
        => _db.StringSetAsync(key, value, when: When.Always, expiry: ttl);

    public async Task AppendListAsync(string key, string value, CancellationToken ct = default)
        => await _db.ListRightPushAsync(key, value);

    public async Task<IReadOnlyList<string>> GetListAsync(string key, CancellationToken ct = default)
    {
        var vals = await _db.ListRangeAsync(key);
        return vals.Select(v => v.ToString()).ToList();
    }

    public async ValueTask DisposeAsync()
    {
        await _mux.CloseAsync();
        _mux.Dispose();
    }
}
