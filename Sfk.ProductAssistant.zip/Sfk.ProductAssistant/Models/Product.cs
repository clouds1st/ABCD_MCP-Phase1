namespace Sfk.ProductAssistant.Models;

public sealed class Product
{
    public string Designation { get; set; } = "";
    // Store attributes in a normalized dictionary (lowercase keys).
    public Dictionary<string, string> Attributes { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}
