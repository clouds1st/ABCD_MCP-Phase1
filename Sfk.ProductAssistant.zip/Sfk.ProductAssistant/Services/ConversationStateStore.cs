using System.Collections.Concurrent;

namespace Sfk.ProductAssistant.Services;

public sealed class ConversationState
{
    public string? LastDesignation { get; set; }
    public string? LastAttribute { get; set; }
    public string? LastAnswer { get; set; }
}

public sealed class ConversationStateStore
{
    private readonly ConcurrentDictionary<string, ConversationState> _state = new();

    public ConversationState Get(string conversationId)
    {
        return _state.GetOrAdd(conversationId, _ => new ConversationState());
    }

    public void Update(string conversationId, Action<ConversationState> updater)
    {
        var s = Get(conversationId);
        updater(s);
    }
}
