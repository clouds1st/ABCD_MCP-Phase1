
# SKF Product Assistant (Mini) — Azure Functions + Semantic Kernel (C#)

**Architect & POC Owner: Ranjeet Bhargava**

This project is a high-performance, single-HTTP-endpoint microservice designed to handle technical queries regarding bearing attributes. It leverages **Semantic Kernel** and **Azure OpenAI** function calling to orchestrate specialized agents that interface with authoritative **local JSON datasheets**.

## System Architecture

The workflow follows a strict orchestration pattern:

1. **Trigger**: HTTP POST request via Azure Function.
2. **Orchestrator**: Analyzes intent and routes to the appropriate agent.
3. **Agents (Q&A/Feedback)**: Utilize Semantic Kernel Plugins to interact with data.
4. **Persistence**: State is managed via `ConversationStateStore` with optional Redis backing.

---

## Core Features

* **Unified Orchestration**: A single entry point (`/api/chat`) managing multi-agent workflows.
* **Dual-Agent Architecture**:
* **Q&A Agent**: Optimized for high-precision attribute lookup.
* **Feedback Agent**: Specifically for persisting user-driven data corrections.


* **Intelligent Function Calling**: Native integration of Extraction, Cache, Datasheet, and Feedback plugins.
* **Stateful Conversations**: Contextual awareness across turns managed via `conversationId`.
* **Hallucination Guardrails**: Strict system prompts and a  temperature setting ensure responses stay grounded in JSON data.

---

## Quick Start & Setup

1. **Configuration**: Copy `local.settings.json.example` to `local.settings.json` and fill in your Azure OpenAI credentials.
2. **Data**: Ensure `Data/bearings_a.json` and `Data/bearings_b.json` exist in the root.
3. **Run**:
```bash
dotnet restore
func start

```



---

## Interaction Examples

### Technical Attribute Query

```bash
curl -s -X POST http://localhost:7071/api/chat \
     -H "Content-Type: application/json" \
     -d '{"conversationId":"demo1","message":"What is the width of 6205?"}'

```

### Feedback & Data Correction

```bash
curl -s -X POST http://localhost:7071/api/chat \
     -H "Content-Type: application/json" \
     -d '{"conversationId":"demo1","message":"That last width is wrong—store my correction: 6205 width 15 mm."}'

```

---

## Design Patterns & AI Validation (Applied)

### 🏗️ Architecture & SOLID Principles

* **Dependency Injection (DI)**: Interfaces used for KV stores and services to ensure the system is unit-testable and infrastructure-agnostic.
* **Single Responsibility**: Logic is decoupled into Function triggers, Orchestrators, Agents, and Plugins.
* **Interface Segregation**: Clean boundaries between the repository layer and the AI orchestration layer.

### 🛡️ Security & Reliability

* **Input Sanitization**: Strict validation of `conversationId` and message length caps to prevent injection or resource exhaustion.
* **Secret Management**: Zero-secret policy in code; all configurations are pulled from environment variables.
* **Error Handling**: Graceful degradation—if the AI cannot find a value or the cache fails, the system returns a standard "Abstain" response rather than hallucinating.

### ☁️ Cloud-Native Implementation

* **Feature Flagging**: The `USE_REDIS` toggle allows for seamless switching between local development (In-memory) and production-scale (Redis) environments.
* **Stateless Scaling**: Azure Functions allow the compute layer to scale independently while the state is offloaded to Redis.

---

---

# SKF Product Assistant (Mini) — Azure Functions + Semantic Kernel (C#)

**Architect & POC Owner: Ranjeet Bhargava**

This project is a high-performance, single-HTTP-endpoint microservice designed to handle technical queries regarding bearing attributes. It leverages **Semantic Kernel** and **Azure OpenAI** function calling to orchestrate specialized agents that interface with authoritative **local JSON datasheets**.

## System Architecture

The workflow follows a strict orchestration pattern:

1. **Trigger**: HTTP POST request via Azure Function.
2. **Orchestrator**: Analyzes intent (Classification) and routes to the appropriate agent.
3. **Agents (Q&A/Feedback)**: Utilize Semantic Kernel Plugins to interact with data.
4. **Persistence**: State is managed via `ConversationStateStore` with optional Redis backing.

---

## Core Features

* **Unified Orchestration**: A single entry point (`/api/chat`) managing multi-agent workflows.
* **Dual-Agent Architecture**:
* **Q&A Agent**: Optimized for high-precision attribute lookup and technical extraction.
* **Feedback Agent**: Specifically for persisting user-driven data corrections and refinements.


* **Intelligent Function Calling**: Native integration of Extraction, Cache, Datasheet, and Feedback plugins.
* **Stateful Conversations**: Contextual awareness across turns managed via `conversationId`.
* **Hallucination Guardrails**: Strict system prompts and a **0.0 temperature** setting ensure responses stay grounded in JSON data.

---

## Quick Start & Setup

1. **Configuration**: Copy `local.settings.json.example` to `local.settings.json` and fill in your Azure OpenAI credentials.
2. **Data**: Ensure `Data/bearings_a.json` and `Data/bearings_b.json` exist in the root directory.
3. **Run**:
```bash
dotnet restore
func start

```



---

## Interaction Examples

### Technical Attribute Query

```bash
curl -s -X POST http://localhost:7071/api/chat \
     -H "Content-Type: application/json" \
     -d '{"conversationId":"demo1","message":"What is the width of 6205?"}'

```

### Feedback & Data Correction

```bash
curl -s -X POST http://localhost:7071/api/chat \
     -H "Content-Type: application/json" \
     -d '{"conversationId":"demo1","message":"That last width is wrong—store my correction: 6205 width 15 mm."}'

```

---

## Design Patterns & AI Validation (Applied)

### 🏗️ Architecture & SOLID Principles

* **Dependency Injection (DI)**: Interfaces used for KV stores and services to ensure the system is unit-testable and infrastructure-agnostic.
* **Single Responsibility (SRP)**: Logic is decoupled into Function triggers, Orchestrators, Agents, and Plugins.
* **Interface Segregation**: Clean boundaries between the repository layer and the AI orchestration layer.

### 🛡️ Security & Reliability

* **Input Sanitization**: Strict validation of `conversationId` and message length caps to prevent prompt injection or resource exhaustion.
* **Secret Management**: Zero-secret policy in code; all configurations are pulled from environment variables.
* **Error Handling**: Graceful degradation—if the AI cannot find a value or the cache fails, the system returns a standard "Abstain" response rather than hallucinating.

### ☁️ Cloud-Native Implementation

* **Feature Flagging**: The `USE_REDIS` toggle allows for seamless switching between local development (In-memory) and production-scale (Redis) environments.
* **Stateless Scaling**: Azure Functions allow the compute layer to scale independently while the state is offloaded to a persistent store.

---

**© 2026 Ranjeet Bhargava.** *All rights reserved. This Proof of Concept (POC) and its architectural design are the intellectual property of Ranjeet Bhargava.*

---
