namespace Sfk.ProductAssistant.Models;

public sealed class FeedbackItem
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public DateTimeOffset Timestamp { get; set; } = DateTimeOffset.UtcNow;
    public string ConversationId { get; set; } = "";
    public string UserText { get; set; } = "";
    public string? Designation { get; set; }
    public string? Attribute { get; set; }
    public string? CorrectedValue { get; set; }
    public string? Unit { get; set; }
    public string? Kind { get; set; } // e.g., correction, helpful, unhelpful, note
}
