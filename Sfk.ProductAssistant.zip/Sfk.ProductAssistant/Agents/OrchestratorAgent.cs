using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;

namespace Sfk.ProductAssistant.Agents;

public sealed class OrchestratorAgent
{
    private readonly Func<Kernel> _kernelFactory;

    public OrchestratorAgent(Func<Kernel> kernelFactory)
    {
        _kernelFactory = kernelFactory;
    }

    public async Task<string> ClassifyAsync(string message, CancellationToken ct = default)
    {
        /* Pseudocode / Plan:
           1. Create the kernel and get the IChatCompletionService.
           2. Build a ChatHistory instance and add system + user messages.
           3. Create OpenAIPromptExecutionSettings with Temperature = 0.0.
           4. Call the correct SDK method that accepts a ChatHistory (not a string):
              GetChatMessageContentsAsync(ChatHistory, PromptExecutionSettings, Kernel?, CancellationToken)
           5. Take the first returned ChatMessageContent (if any), read .Content, normalize.
           6. Return exactly "question" or "feedback" (default to "question").
        */

        var kernel = _kernelFactory();
        var chat = kernel.GetRequiredService<IChatCompletionService>();

        var sys = """
        You are a strict intent classifier for an engineering helper.
        Output exactly one word: "question" if the user asks for product attributes or clarification.
        Output "feedback" if the user provides corrections, marks helpful/unhelpful, or asks to store notes.
        Never output anything else.
        """;

        var conv = new ChatHistory();
        conv.AddSystemMessage(sys);
        conv.AddUserMessage(message);

        var settings = new OpenAIPromptExecutionSettings
        {
            Temperature = 0.0,
        };

        // Use the overload that accepts a ChatHistory and the Kernel, then the CancellationToken.
        var responses = await chat.GetChatMessageContentsAsync(conv, settings, kernel, ct);
        var resp = (responses != null && responses.Count > 0) ? responses[0] : null;

        var label = resp?.Content?.Trim().ToLowerInvariant() ?? "question";
        return (label == "feedback") ? "feedback" : "question";
    }
}
