using Microsoft.SemanticKernel;
using Sfk.ProductAssistant.Models;
using System.Text.RegularExpressions;
using System.ComponentModel;

namespace Sfk.ProductAssistant.Plugins;

public sealed class ExtractionPlugin
{
    // Simple deterministic extractor. The model can choose to call this function.
    [KernelFunction, Description("Extract product designation and attribute name from a user's question or feedback.")]
    public QueryParts ExtractQueryParts(
        [Description("User's raw utterance")] string userText,
        [Description("Fallback designation from conversation state if available")] string? lastDesignation = null,
        [Description("Fallback attribute from conversation state if available")] string? lastAttribute = null)
    {
        // Very conservative regex for SKF-like bearing numbers (e.g., 6205, 6205 N, 6205-2Z)
        var designationMatch = Regex.Match(userText, @"([1-9]\d{3}(?:[\-\s]?[A-Z0-9]+)*)");
        string? designation = designationMatch.Success ? designationMatch.Groups[1].Value.Replace(" ", "") : null;

        // Attribute extraction: look for common attribute words
        string? attribute = null;
        var lowered = userText.ToLowerInvariant();
        var attrCandidates = new[] { "width", "height", "diameter", "bore", "outer diameter", "inner diameter" };
        foreach (var cand in attrCandidates)
        {
            if (lowered.Contains(cand))
            {
                attribute = cand switch
                {
                    "outer diameter" => "diameter",
                    "inner diameter" => "bore",
                    _ => cand
                };
                break;
            }
        }

        // Unit guessing (optional)
        string? unit = null;
        if (Regex.IsMatch(lowered, @"mm")) unit = "mm";

        designation ??= lastDesignation;
        attribute ??= lastAttribute;

        return new QueryParts
        {
            Designation = designation,
            Attribute = attribute,
            Unit = unit
        };
    }
}
