using Microsoft.SemanticKernel;
using Sfk.ProductAssistant.Services.KeyValueStores;
using System.ComponentModel;

namespace Sfk.ProductAssistant.Plugins;

public sealed class CachePlugin
{
    private readonly IKeyValueStore _store;

    public CachePlugin(IKeyValueStore store) => _store = store;

    private static string Key(string designation, string attribute) => $"cache:{designation.ToLowerInvariant()}:{attribute.ToLowerInvariant()}";

    [KernelFunction, Description("Try to get an attribute value from cache.")]
    public async Task<string?> GetCachedAsync(
        [Description("Product designation")] string designation,
        [Description("Attribute name")] string attribute)
    {
        return await _store.GetAsync(Key(designation, attribute));
    }

    [KernelFunction, Description("Save an attribute value to cache.")]
    public async Task SaveCachedAsync(
        [Description("Product designation")] string designation,
        [Description("Attribute name")] string attribute,
        [Description("Attribute value including unit if any")] string value)
    {
        await _store.SetAsync(Key(designation, attribute), value, ttl: TimeSpan.FromHours(12));
    }
}
