namespace Sfk.ProductAssistant.Models;

public sealed class ChatRequest
{
    public string? ConversationId { get; set; }
    public string Message { get; set; } = "";
}

public sealed class ChatResponse
{
    public string ConversationId { get; set; } = "";
    public string Agent { get; set; } = "";
    public string Reply { get; set; } = "";
    public string? Designation { get; set; }
    public string? Attribute { get; set; }
}
