using Microsoft.SemanticKernel;
using Sfk.ProductAssistant.Models;
using Sfk.ProductAssistant.Services.KeyValueStores;
using System.Text.Json;
using System.ComponentModel;

namespace Sfk.ProductAssistant.Plugins;

public sealed class FeedbackPlugin
{
    private readonly IKeyValueStore _store;
    private const string FeedbackListKeyPrefix = "feedback:"; // feedback:{conversationId}

    public FeedbackPlugin(IKeyValueStore store) => _store = store;

    [KernelFunction, Description("Persist user feedback item.")]
    public async Task<string> SaveFeedbackAsync(
        [Description("Conversation identifier to link feedback to context")] string conversationId,
        [Description("Raw user feedback text")] string userText,
        [Description("Normalized designation if available")] string? designation = null,
        [Description("Normalized attribute if available")] string? attribute = null,
        [Description("Corrected value if the feedback is a correction")] string? correctedValue = null,
        [Description("Unit of the corrected value, e.g., mm")] string? unit = null,
        [Description("Kind of feedback (correction/helpful/unhelpful/note)")] string? kind = null)
    {
        var item = new FeedbackItem
        {
            ConversationId = conversationId,
            UserText = userText,
            Designation = designation,
            Attribute = attribute,
            CorrectedValue = correctedValue,
            Unit = unit,
            Kind = kind
        };
        var json = JsonSerializer.Serialize(item);
        await _store.AppendListAsync($"{FeedbackListKeyPrefix}{conversationId}", json);
        return item.Id;
    }

    [KernelFunction, Description("Get all feedback items for a conversation.")]
    public async Task<IEnumerable<FeedbackItem>> GetFeedbackAsync(
        [Description("Conversation identifier")] string conversationId)
    {
        var list = await _store.GetListAsync($"{FeedbackListKeyPrefix}{conversationId}");
        return list.Select(j =>
        {
            try { return JsonSerializer.Deserialize<FeedbackItem>(j)!; } catch { return null!; }
        }).Where(x => x is not null)!;
    }
}
