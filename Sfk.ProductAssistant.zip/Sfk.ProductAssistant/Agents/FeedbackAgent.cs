using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using Sfk.ProductAssistant.Plugins;
using Sfk.ProductAssistant.Services;

namespace Sfk.ProductAssistant.Agents;

public sealed class FeedbackAgent
{
    private readonly Func<Kernel> _kernelFactory;
    private readonly ExtractionPlugin _extraction;
    private readonly FeedbackPlugin _feedback;
    private readonly ConversationStateStore _state;

    public FeedbackAgent(Func<Kernel> kernelFactory, ExtractionPlugin extraction, FeedbackPlugin feedback, ConversationStateStore state)
    {
        _kernelFactory = kernelFactory;
        _extraction = extraction;
        _feedback = feedback;
        _state = state;
    }

    public async Task<string> CaptureAsync(string conversationId, string userMessage, CancellationToken ct = default)
    {
        var kernel = _kernelFactory();
        kernel.Plugins.AddFromObject(_extraction, "extractor");
        kernel.Plugins.AddFromObject(_feedback, "feedback");

        var chat = kernel.GetRequiredService<IChatCompletionService>();
        var s = _state.Get(conversationId);

        var system = """
        You capture feedback about answers.
        - If user provides a correction, normalize product designation and attribute using the extractor.
        - If not present, use lastDesignation/lastAttribute from context where possible.
        - Save feedback using feedback.SaveFeedbackAsync().
        - Confirm concisely, e.g., "Thanks—your feedback for 6205 / width has been saved."
        """;

        var conv = new ChatHistory();
        conv.AddSystemMessage(system);

        if (!string.IsNullOrWhiteSpace(s.LastAnswer))
        {
            conv.AddAssistantMessage($"Previous answer: {s.LastAnswer}");
        }
        conv.AddAssistantMessage($"Context: lastDesignation={s.LastDesignation ?? ""}; lastAttribute={s.LastAttribute ?? ""}");

        conv.AddUserMessage(userMessage);

        var settings = new OpenAIPromptExecutionSettings
        {
            Temperature = 0.0,
            ToolCallBehavior = ToolCallBehavior.AutoInvokeKernelFunctions
        };

        conv.AddSystemMessage("""
        Steps:
        1) extractor.ExtractQueryParts(userText, lastDesignation, lastAttribute)
        2) Decide feedback kind: correction/helpful/unhelpful/note
        3) If correction includes a value, include correctedValue + unit if provided
        4) feedback.SaveFeedbackAsync(conversationId, userText, designation, attribute, correctedValue, unit, kind)
        Then confirm concisely.
        """);

        // Use the ChatHistory overload and pass the kernel and cancellation token in the correct positions.
        var results = await chat.GetChatMessageContentsAsync(conv, settings, kernel, ct);

        //await chat.GetChatMessageContentsAsync(
        //    IPromptTemplate: conv.ToString(),
        //    settings: settings,
        //    cancellationToken: ct);

        var first = results.FirstOrDefault();
        var reply = (first?.Content ?? "Thanks—your feedback has been saved.").Trim();
        return reply;
    }
}
