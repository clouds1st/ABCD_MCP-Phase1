using System;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using Sfk.ProductAssistant.Plugins;
using Sfk.ProductAssistant.Services;

namespace Sfk.ProductAssistant.Agents;

public sealed class QaAgent
{
    private readonly Func<Kernel> _kernelFactory;
    private readonly ExtractionPlugin _extraction;
    private readonly DatasheetPlugin _datasheet;
    private readonly CachePlugin _cache;
    private readonly ConversationStateStore _state;

    public QaAgent(Func<Kernel> kernelFactory, ExtractionPlugin extraction, DatasheetPlugin datasheet, CachePlugin cache, ConversationStateStore state)
    {
        _kernelFactory = kernelFactory;
        _extraction = extraction;
        _datasheet = datasheet;
        _cache = cache;
        _state = state;
    }

    public async Task<(string reply, string? designation, string? attribute)> AnswerAsync(string conversationId, string userMessage, CancellationToken ct = default)
    {
        var kernel = _kernelFactory();
        // Attach plugins as tools
        kernel.Plugins.AddFromObject(_extraction, "extractor");
        kernel.Plugins.AddFromObject(_cache, "cache");
        kernel.Plugins.AddFromObject(_datasheet, "datasheet");

        var chat = kernel.GetRequiredService<IChatCompletionService>();
        var s = _state.Get(conversationId);

        var system = """
        You are a concise product Q&A agent for bearings. 
        Strict rules:
        - Always use tools to extract designation/attribute if needed.
        - Try cache first; if miss, read from datasheets.
        - NEVER invent data. If not found, say you can't find it.
        - Respond concisely, e.g., "The width of the 6205 bearing is 15 mm."
        - If unit isn't explicitly in datasheet value, do not add one unless user stated it.
        """;

        var conv = new ChatHistory();
        conv.AddSystemMessage(system);

        // Minimal helpful context for follow-ups
        if (!string.IsNullOrWhiteSpace(s.LastAnswer))
        {
            conv.AddAssistantMessage($"Previous answer: {s.LastAnswer}");
        }
        if (!string.IsNullOrWhiteSpace(s.LastDesignation) || !string.IsNullOrWhiteSpace(s.LastAttribute))
        {
            conv.AddAssistantMessage($"Context: designation={s.LastDesignation ?? "?"}, attribute={s.LastAttribute ?? "?"}");
        }

        conv.AddUserMessage(userMessage);

        var settings = new OpenAIPromptExecutionSettings
        {
            Temperature = 0.0,
            ToolCallBehavior = ToolCallBehavior.AutoInvokeKernelFunctions
        };

        // The prompt instructs the model to call functions in the following pattern:
        conv.AddSystemMessage("""
        When needed, call:
         1) extractor.ExtractQueryParts(userText, lastDesignation, lastAttribute)
         2) cache.GetCachedAsync(designation, attribute)
         3) If null, datasheet.LookupAttribute(designation, attribute)
         4) If found, cache.SaveCachedAsync(designation, attribute, value)
        Then answer concisely.
        If designation or attribute is unknown after extraction, ask user to specify.
        """);

        // Provide last state so extraction can use fallbacks
        conv.AddAssistantMessage($"lastDesignation={s.LastDesignation ?? ""}; lastAttribute={s.LastAttribute ?? ""}");

        // FIX:
        // Call the correct interface method and pass the kernel as the third argument.
        // The method returns a list of ChatMessageContent; take the first one as the assistant reply.
        var messages = await chat.GetChatMessageContentsAsync(conv, settings, kernel, ct);
        var first = messages != null && messages.Count > 0 ? messages[0] : null;
        var reply = (first?.Content ?? "Sorry, I can’t find that information.").Trim();

        // Heuristically update state: attempt a quick extract locally once more for state
        var qp = _extraction.ExtractQueryParts(userMessage, s.LastDesignation, s.LastAttribute);
        if (!string.IsNullOrWhiteSpace(qp.Designation)) s.LastDesignation = qp.Designation;
        if (!string.IsNullOrWhiteSpace(qp.Attribute)) s.LastAttribute = qp.Attribute;
        s.LastAnswer = reply;

        return (reply, s.LastDesignation, s.LastAttribute);
    }
}
