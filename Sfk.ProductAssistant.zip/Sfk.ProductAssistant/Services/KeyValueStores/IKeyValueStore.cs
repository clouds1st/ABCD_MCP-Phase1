namespace Sfk.ProductAssistant.Services.KeyValueStores;

public interface IKeyValueStore
{
    Task<string?> GetAsync(string key, CancellationToken ct = default);
    Task SetAsync(string key, string value, TimeSpan? ttl = null, CancellationToken ct = default);
    Task AppendListAsync(string key, string value, CancellationToken ct = default);
    Task<IReadOnlyList<string>> GetListAsync(string key, CancellationToken ct = default);
}
